export class CreateRegistrantDto {
    accountNumber: string;
    meterNumber?: string;
    consumerName?: string;
    consumerAddress?: string;
    town?: string;
    area?: string;
    district?: string;
  }
  